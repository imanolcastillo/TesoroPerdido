﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tesoro_perdido
{
    public partial class Frm_TesoroPerdido : Form
    {
        public Frm_TesoroPerdido()
        {
            InitializeComponent();
            JugarDeNuevo.Enabled = false;
            gif.Visible = false;
            imagen_perder.Visible = false;

        }

        int won = 0;
        private void cofre1_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            if(cofre1.Text == "Cofre #1")
            {
                cofre1.Text = Convert.ToString(r.Next(1, 3));
                cofre2.Enabled = false;
                cofre3.Enabled = false;
                JugarDeNuevo.Enabled = true;
                if (cofre1.Text == "2")
                {
                    cofre1.Text = Convert.ToString("¡TESORO!");
                    gif.Visible = true;
                }
                if (cofre1.Text == "1" || cofre1.Text == "3")
                {
                    cofre1.Text = Convert.ToString(":(");
                    imagen_perder.Visible = true;
                }
                if (cofre1.Text == "¡TESORO!")
                {
                    if (won < 10000)
                    {
                        won++;
                        tb_ganados.Text = Convert.ToString(won);
                    }
                }
            }
        }

        private void cofre2_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            if (cofre2.Text == "Cofre #2")
            {
                cofre2.Text = Convert.ToString(r.Next(1, 3));
                cofre1.Enabled = false;
                cofre3.Enabled = false;
                JugarDeNuevo.Enabled = true;
                if (cofre2.Text == "2")
                {
                    cofre2.Text = Convert.ToString("¡TESORO!");
                    gif.Visible = true;
                }
                if (cofre2.Text == "1" || cofre2.Text == "3")
                {
                    cofre2.Text = Convert.ToString(":(");
                    imagen_perder.Visible = true;
                }
                if (cofre2.Text == "¡TESORO!")
                {
                    if (won < 10000)
                    {
                        won++;
                        tb_ganados.Text = Convert.ToString(won);
                    }
                }
            }
        }

        private void cofre3_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            if (cofre3.Text == "Cofre #3")
            {
                cofre3.Text = Convert.ToString(r.Next(1, 3));
                cofre1.Enabled = false;
                cofre2.Enabled = false;
                JugarDeNuevo.Enabled = true;
                if (cofre3.Text == "2")
                {
                    cofre3.Text = Convert.ToString("¡TESORO!");
                    gif.Visible = true;
                }
                if(cofre3.Text == "1" || cofre3.Text == "3")
                {
                    cofre3.Text = Convert.ToString(":(");
                    imagen_perder.Visible = true;
                }
                if (cofre3.Text == "¡TESORO!")
                {
                    if (won < 10000)
                    {
                        won++;
                        tb_ganados.Text = Convert.ToString(won);
                    }
                }
            }
        }

        int contador = 0;
        private void JugarDeNuevo_Click(object sender, EventArgs e)
        {
            if (contador < 1000)
            {
                contador++;
                tb_realizados.Text = Convert.ToString(contador);
                cofre1.Text = "Cofre #1";
                cofre2.Text = "Cofre #2";
                cofre3.Text = "Cofre #3";
            }
            cofre1.Enabled = true;
            cofre2.Enabled = true;
            cofre3.Enabled = true;
            JugarDeNuevo.Enabled = false;
            gif.Visible = false;
            imagen_perder.Visible = false;
        }
    }
}
