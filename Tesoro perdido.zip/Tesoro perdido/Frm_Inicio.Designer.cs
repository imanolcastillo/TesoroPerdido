﻿namespace Tesoro_perdido
{
    partial class Frm_Inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Inicio));
            this.but_ins = new System.Windows.Forms.Button();
            this.but_jugar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // but_ins
            // 
            this.but_ins.BackColor = System.Drawing.Color.Transparent;
            this.but_ins.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("but_ins.BackgroundImage")));
            this.but_ins.Cursor = System.Windows.Forms.Cursors.Default;
            this.but_ins.FlatAppearance.BorderSize = 0;
            this.but_ins.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but_ins.Font = new System.Drawing.Font("News706 BT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_ins.Location = new System.Drawing.Point(93, 404);
            this.but_ins.Name = "but_ins";
            this.but_ins.Size = new System.Drawing.Size(150, 50);
            this.but_ins.TabIndex = 0;
            this.but_ins.Text = "Instrucciones";
            this.but_ins.UseVisualStyleBackColor = false;
            this.but_ins.Click += new System.EventHandler(this.but_ins_Click);
            // 
            // but_jugar
            // 
            this.but_jugar.BackColor = System.Drawing.Color.Transparent;
            this.but_jugar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("but_jugar.BackgroundImage")));
            this.but_jugar.Cursor = System.Windows.Forms.Cursors.Default;
            this.but_jugar.FlatAppearance.BorderSize = 0;
            this.but_jugar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.but_jugar.Font = new System.Drawing.Font("News706 BT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_jugar.Location = new System.Drawing.Point(287, 404);
            this.but_jugar.Name = "but_jugar";
            this.but_jugar.Size = new System.Drawing.Size(150, 50);
            this.but_jugar.TabIndex = 1;
            this.but_jugar.Text = "Juego";
            this.but_jugar.UseVisualStyleBackColor = false;
            this.but_jugar.Click += new System.EventHandler(this.but_jugar_Click);
            // 
            // Frm_Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(700, 543);
            this.Controls.Add(this.but_jugar);
            this.Controls.Add(this.but_ins);
            this.Name = "Frm_Inicio";
            this.Text = "Tesoro Perdido";
            this.Load += new System.EventHandler(this.Frm_Inicio_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button but_ins;
        private System.Windows.Forms.Button but_jugar;
    }
}