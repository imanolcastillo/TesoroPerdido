﻿namespace Tesoro_perdido
{
    partial class Frm_TesoroPerdido
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_TesoroPerdido));
            this.cofre1 = new System.Windows.Forms.Button();
            this.cofre3 = new System.Windows.Forms.Button();
            this.cofre2 = new System.Windows.Forms.Button();
            this.realizados = new System.Windows.Forms.Label();
            this.resultJuegosRealizados = new System.Windows.Forms.Label();
            this.ganados = new System.Windows.Forms.Label();
            this.resultJuegosGanados = new System.Windows.Forms.Label();
            this.JugarDeNuevo = new System.Windows.Forms.Button();
            this.tb_realizados = new System.Windows.Forms.TextBox();
            this.tb_ganados = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.gif = new System.Windows.Forms.PictureBox();
            this.imagen_perder = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gif)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagen_perder)).BeginInit();
            this.SuspendLayout();
            // 
            // cofre1
            // 
            this.cofre1.BackColor = System.Drawing.Color.Transparent;
            this.cofre1.BackgroundImage = global::Tesoro_perdido.Properties.Resources.sin_fondo;
            this.cofre1.Cursor = System.Windows.Forms.Cursors.Default;
            this.cofre1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cofre1.Font = new System.Drawing.Font("News706 BT", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cofre1.Location = new System.Drawing.Point(85, 261);
            this.cofre1.Name = "cofre1";
            this.cofre1.Size = new System.Drawing.Size(103, 45);
            this.cofre1.TabIndex = 2;
            this.cofre1.Text = "Cofre #1";
            this.cofre1.UseVisualStyleBackColor = false;
            this.cofre1.Click += new System.EventHandler(this.cofre1_Click);
            // 
            // cofre3
            // 
            this.cofre3.BackColor = System.Drawing.Color.Transparent;
            this.cofre3.BackgroundImage = global::Tesoro_perdido.Properties.Resources.pergamino;
            this.cofre3.Cursor = System.Windows.Forms.Cursors.Default;
            this.cofre3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cofre3.Font = new System.Drawing.Font("News706 BT", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cofre3.ForeColor = System.Drawing.Color.Black;
            this.cofre3.Location = new System.Drawing.Point(532, 261);
            this.cofre3.Name = "cofre3";
            this.cofre3.Size = new System.Drawing.Size(103, 45);
            this.cofre3.TabIndex = 3;
            this.cofre3.Text = "Cofre #3";
            this.cofre3.UseVisualStyleBackColor = false;
            this.cofre3.Click += new System.EventHandler(this.cofre3_Click);
            // 
            // cofre2
            // 
            this.cofre2.BackColor = System.Drawing.Color.Transparent;
            this.cofre2.BackgroundImage = global::Tesoro_perdido.Properties.Resources.pergamino;
            this.cofre2.Cursor = System.Windows.Forms.Cursors.Default;
            this.cofre2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cofre2.Font = new System.Drawing.Font("News706 BT", 12.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cofre2.Location = new System.Drawing.Point(314, 261);
            this.cofre2.Name = "cofre2";
            this.cofre2.Size = new System.Drawing.Size(103, 45);
            this.cofre2.TabIndex = 5;
            this.cofre2.Text = "Cofre #2";
            this.cofre2.UseVisualStyleBackColor = false;
            this.cofre2.Click += new System.EventHandler(this.cofre2_Click);
            // 
            // realizados
            // 
            this.realizados.AutoSize = true;
            this.realizados.BackColor = System.Drawing.Color.Peru;
            this.realizados.Cursor = System.Windows.Forms.Cursors.Default;
            this.realizados.Font = new System.Drawing.Font("News706 BT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.realizados.Location = new System.Drawing.Point(12, 359);
            this.realizados.Name = "realizados";
            this.realizados.Size = new System.Drawing.Size(183, 22);
            this.realizados.TabIndex = 7;
            this.realizados.Text = "Juegos realizados:";
            // 
            // resultJuegosRealizados
            // 
            this.resultJuegosRealizados.AutoSize = true;
            this.resultJuegosRealizados.BackColor = System.Drawing.Color.Transparent;
            this.resultJuegosRealizados.Cursor = System.Windows.Forms.Cursors.Default;
            this.resultJuegosRealizados.Font = new System.Drawing.Font("News706 BT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultJuegosRealizados.Location = new System.Drawing.Point(104, 392);
            this.resultJuegosRealizados.Name = "resultJuegosRealizados";
            this.resultJuegosRealizados.Size = new System.Drawing.Size(0, 19);
            this.resultJuegosRealizados.TabIndex = 8;
            // 
            // ganados
            // 
            this.ganados.AutoSize = true;
            this.ganados.BackColor = System.Drawing.Color.Peru;
            this.ganados.Cursor = System.Windows.Forms.Cursors.Default;
            this.ganados.Font = new System.Drawing.Font("News706 BT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ganados.Location = new System.Drawing.Point(24, 421);
            this.ganados.Name = "ganados";
            this.ganados.Size = new System.Drawing.Size(164, 22);
            this.ganados.TabIndex = 9;
            this.ganados.Text = "Juegos ganados:";
            // 
            // resultJuegosGanados
            // 
            this.resultJuegosGanados.AutoSize = true;
            this.resultJuegosGanados.BackColor = System.Drawing.Color.Transparent;
            this.resultJuegosGanados.Cursor = System.Windows.Forms.Cursors.Default;
            this.resultJuegosGanados.Font = new System.Drawing.Font("News706 BT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultJuegosGanados.Location = new System.Drawing.Point(104, 456);
            this.resultJuegosGanados.Name = "resultJuegosGanados";
            this.resultJuegosGanados.Size = new System.Drawing.Size(0, 19);
            this.resultJuegosGanados.TabIndex = 10;
            // 
            // JugarDeNuevo
            // 
            this.JugarDeNuevo.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.JugarDeNuevo.BackgroundImage = global::Tesoro_perdido.Properties.Resources.monedaalt;
            this.JugarDeNuevo.Cursor = System.Windows.Forms.Cursors.Default;
            this.JugarDeNuevo.Font = new System.Drawing.Font("News706 BT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JugarDeNuevo.Location = new System.Drawing.Point(26, 489);
            this.JugarDeNuevo.Name = "JugarDeNuevo";
            this.JugarDeNuevo.Size = new System.Drawing.Size(159, 42);
            this.JugarDeNuevo.TabIndex = 12;
            this.JugarDeNuevo.Text = "Jugar de nuevo";
            this.JugarDeNuevo.UseVisualStyleBackColor = false;
            this.JugarDeNuevo.Click += new System.EventHandler(this.JugarDeNuevo_Click);
            // 
            // tb_realizados
            // 
            this.tb_realizados.BackColor = System.Drawing.Color.PeachPuff;
            this.tb_realizados.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_realizados.Cursor = System.Windows.Forms.Cursors.Default;
            this.tb_realizados.Font = new System.Drawing.Font("News706 BT", 12.25F, System.Drawing.FontStyle.Bold);
            this.tb_realizados.Location = new System.Drawing.Point(53, 393);
            this.tb_realizados.Name = "tb_realizados";
            this.tb_realizados.ReadOnly = true;
            this.tb_realizados.Size = new System.Drawing.Size(100, 20);
            this.tb_realizados.TabIndex = 13;
            this.tb_realizados.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tb_ganados
            // 
            this.tb_ganados.BackColor = System.Drawing.Color.PeachPuff;
            this.tb_ganados.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_ganados.Cursor = System.Windows.Forms.Cursors.Default;
            this.tb_ganados.Font = new System.Drawing.Font("News706 BT", 12.25F, System.Drawing.FontStyle.Bold);
            this.tb_ganados.Location = new System.Drawing.Point(53, 455);
            this.tb_ganados.Name = "tb_ganados";
            this.tb_ganados.ReadOnly = true;
            this.tb_ganados.Size = new System.Drawing.Size(100, 20);
            this.tb_ganados.TabIndex = 14;
            this.tb_ganados.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(-23, -46);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // gif
            // 
            this.gif.Image = ((System.Drawing.Image)(resources.GetObject("gif.Image")));
            this.gif.Location = new System.Drawing.Point(231, 359);
            this.gif.Name = "gif";
            this.gif.Size = new System.Drawing.Size(210, 172);
            this.gif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gif.TabIndex = 16;
            this.gif.TabStop = false;
            // 
            // imagen_perder
            // 
            this.imagen_perder.Image = ((System.Drawing.Image)(resources.GetObject("imagen_perder.Image")));
            this.imagen_perder.Location = new System.Drawing.Point(283, 359);
            this.imagen_perder.Name = "imagen_perder";
            this.imagen_perder.Size = new System.Drawing.Size(158, 161);
            this.imagen_perder.TabIndex = 17;
            this.imagen_perder.TabStop = false;
            // 
            // Frm_TesoroPerdido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Tesoro_perdido.Properties.Resources.definitivo;
            this.ClientSize = new System.Drawing.Size(700, 543);
            this.Controls.Add(this.imagen_perder);
            this.Controls.Add(this.gif);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tb_ganados);
            this.Controls.Add(this.tb_realizados);
            this.Controls.Add(this.JugarDeNuevo);
            this.Controls.Add(this.resultJuegosGanados);
            this.Controls.Add(this.ganados);
            this.Controls.Add(this.resultJuegosRealizados);
            this.Controls.Add(this.realizados);
            this.Controls.Add(this.cofre2);
            this.Controls.Add(this.cofre3);
            this.Controls.Add(this.cofre1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Frm_TesoroPerdido";
            this.Text = "Juego";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gif)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imagen_perder)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button cofre1;
        private System.Windows.Forms.Button cofre2;
        private System.Windows.Forms.Button cofre3;
        private System.Windows.Forms.Label realizados;
        private System.Windows.Forms.Label resultJuegosRealizados;
        private System.Windows.Forms.Label ganados;
        private System.Windows.Forms.Label resultJuegosGanados;
        private System.Windows.Forms.Button JugarDeNuevo;
        private System.Windows.Forms.TextBox tb_realizados;
        private System.Windows.Forms.TextBox tb_ganados;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox gif;
        private System.Windows.Forms.PictureBox imagen_perder;
    }
}

