﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tesoro_perdido
{
    public partial class Frm_Inicio : Form
    {
        public Frm_Inicio()
        {
            InitializeComponent();
        }

        private void Frm_Inicio_Load(object sender, EventArgs e)
        {

        }

        private void but_jugar_Click(object sender, EventArgs e)
        {
            Form juego = new Frm_TesoroPerdido();
            juego.Show();
        }

        private void but_ins_Click(object sender, EventArgs e)
        {
            Form juego = new Frm_Instrucciones();
            juego.Show();
        }
    }
}
